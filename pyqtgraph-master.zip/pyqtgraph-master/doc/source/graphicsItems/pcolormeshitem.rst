PColorMeshItem
==============

.. autoclass:: pyqtgraph.PColorMeshItem
    :members:

    .. automethod:: pyqtgraph.PColorMeshItem.__init__

