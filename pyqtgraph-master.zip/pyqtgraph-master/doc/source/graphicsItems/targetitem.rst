TargetItem
==========

.. autoclass:: pyqtgraph.TargetItem
    :members:
    
    .. automethod:: pyqtgraph.TargetItem.__init__


TargetLabel
==================

.. autoclass:: pyqtgraph.TargetLabel
    :members:

    .. automethod:: pyqtgraph.TargetLabel.__init__
        