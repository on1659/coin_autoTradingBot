MultiPlotItem
=============

.. autoclass:: pyqtgraph.MultiPlotItem
    :members:
