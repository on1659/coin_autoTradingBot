ColorBarItem
============

.. autoclass:: pyqtgraph.ColorBarItem
    :members:

    .. automethod:: pyqtgraph.ColorBarItem.__init__
