DateAxisItem
============

.. autoclass:: pyqtgraph.DateAxisItem
    :members:

    .. automethod:: pyqtgraph.DateAxisItem.__init__

