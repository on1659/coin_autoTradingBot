Deprecated Window Classes
=========================

.. automodule:: pyqtgraph.graphicsWindows

.. autoclass:: pyqtgraph.GraphicsWindow
    :members:

.. autoclass:: pyqtgraph.TabWindow
    :members:

.. autoclass:: pyqtgraph.PlotWindow
    :members:

.. autoclass:: pyqtgraph.ImageWindow
    :members:
