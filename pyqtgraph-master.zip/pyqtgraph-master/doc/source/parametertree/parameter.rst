Parameter
=========

.. autofunction:: pyqtgraph.parametertree.registerParameterType

.. autoclass:: pyqtgraph.parametertree.Parameter
    :members:

    .. automethod:: pyqtgraph.parametertree.Parameter.__init__
