DataTreeWidget
==============

.. autoclass:: pyqtgraph.DataTreeWidget
    :members:

    .. automethod:: pyqtgraph.DataTreeWidget.__init__

