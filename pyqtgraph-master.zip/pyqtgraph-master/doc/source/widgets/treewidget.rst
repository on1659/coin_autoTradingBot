TreeWidget
==========

.. autoclass:: pyqtgraph.TreeWidget
    :members:

    .. automethod:: pyqtgraph.TreeWidget.__init__

