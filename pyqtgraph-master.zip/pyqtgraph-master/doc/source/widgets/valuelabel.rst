ValueLabel
==========

.. autoclass:: pyqtgraph.ValueLabel
    :members:

    .. automethod:: pyqtgraph.ValueLabel.__init__

