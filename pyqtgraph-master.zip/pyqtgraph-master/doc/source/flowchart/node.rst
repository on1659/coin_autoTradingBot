flowchart.Node
==============

.. autoclass:: pyqtgraph.flowchart.Node
    :members:

    .. automethod:: pyqtgraph.flowchart.Node.__init__

