GLScatterPlotItem
=================

.. autoclass:: pyqtgraph.opengl.GLScatterPlotItem
    :members:

    .. automethod:: pyqtgraph.opengl.GLScatterPlotItem.__init__

