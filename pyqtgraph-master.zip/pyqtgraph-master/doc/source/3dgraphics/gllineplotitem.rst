GLLinePlotItem
==============

.. autoclass:: pyqtgraph.opengl.GLLinePlotItem
    :members:

    .. automethod:: pyqtgraph.opengl.GLLinePlotItem.__init__

