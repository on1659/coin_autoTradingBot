GLImageItem
===========

.. autoclass:: pyqtgraph.opengl.GLImageItem
    :members:

    .. automethod:: pyqtgraph.opengl.GLImageItem.__init__

